import cv2
import numpy as np

size = 100
img = np.zeros((size, size, 3), np.uint8)
color = [255,255,255]

def draw(coords):
    offset = (int(size/2), int(size/2))
    for pair in coords:
        img[(pair[0] + offset[0]), (pair[1] + offset[1])] = color
        #rotate
        M = cv2.getRotationMatrix2D(offset, 90, 1)
        rotated = cv2.warpAffine(img, M, (size, size))
    #write
    cv2.imwrite("func_graph.png", rotated)
