import draw_func

x_axis = (-10, 10)

def calculate(func):
    #write into file to execute string
    with open("./func.py", "w") as f:
        f.write("def f(x):\n    return {}".format(func))
        f.close()

    #imoport and run
    import func
    result = []
    for x in range(x_axis[0], x_axis[1]):
        result.append((x, func.f(x)))
        
    return(result)

result = calculate(input("f(x)="))
print(result)
draw_func.draw(result)
